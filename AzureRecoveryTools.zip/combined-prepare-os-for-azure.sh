#!/bin/bash

##+----------------------------------------------------------------------------------+
##            Copyright(c) Microsoft Corp. 2015
##+----------------------------------------------------------------------------------+
## File         :   prepare-os-for-azure.sh
##
## Description  :   
##
## History      :   11-11-2018 (Venu Sivanadham) - Created
##
## Usage        :   combined-prepare-os-for-azure.sh <chroot-path>
##+----------------------------------------------------------------------------------+

###Start: Scrip error codes.
_E_AZURE_SMS_INTERNAL=1
_E_AZURE_SMS_HV_DRIVERS_MISSING=2
_E_AZURE_SMS_TOOLS_MISSING=3
_E_AZURE_SMS_ARGS=4
_E_AZURE_SMS_OS_UNSUPPORTED=5
_E_AZURE_SMS_CONF_MISSING=6
# Indicates there was an error in generate_initrd_image step.
_E_AZURE_SMS_INITRD_IMAGE_GENERATION_FAILED=7

###End: Script error codes.

###Start: Constants
_FIX_DHCP_SCRIPT_="fix_dhcp.sh"
_AM_STARTUP_="azure-migrate-startup"
_STARTUP_SCRIPT_="${_AM_STARTUP_}.sh"
_AM_SCRIPT_DIR_="/usr/local/azure-migrate"
_AM_SCRIPT_LOG_FILE_="/var/log/${_AM_STARTUP_}.log"
_AM_INSTALLGA_="asr-installga"
_AM_CUSTOM_SCRIPT_="user-script"
###End: Constants

#@1 - Error Code
#@2 - Error Data
throw_error()
{
    local error_code=$_E_AZURE_SMS_INTERNAL
    [[ $1 =~ [[:digit:]] ]] && error_code=$1
    
    local error_data="Unavailable"
    [[ -z "$2" ]] || error_data="$2"
    
    echo "[Sms-Scrip-Error-Data]:${error_data}"
    
    exit $error_code
}

#@1 - string to log
trace()
{
    echo "$(date +"%a %b %d %Y %T") : $1"
}

unset chroot_path
unset hydration_config_settings
unset custom_config_settings

#@1 - chroot path
validate_script_input()
{
    [[ $# -lt 1 ]] && throw_error $_E_AZURE_SMS_ARGS "chroot-path missing"  
    [[ ! -d "$1" ]] && throw_error $_E_AZURE_SMS_ARGS "$1 invalid"
    
    trace "chroot: $1"

    if [[ $# -eq 2 ]]; then
        trace "Hydration Config Settings: $2"
        hydration_config_settings="$2"
    elif [[ $# -eq 3 ]]; then
        trace "Hydration Config Settings: $2"
        hydration_config_settings="$2"
        trace "Custom Config Settings: $3"
        custom_config_settings="$3"
    fi
    chroot_path="$1"
}

unset src_distro
#@1 - Root path
find_src_distro()
{
    local root_path=$chroot_path
    [[ -z "$1" ]] || root_path=$1
    
    local script_dir=$(cd $(dirname "$0") > /dev/null && pwd)
    [[ -d "$script_dir" ]] || script_dir=/usr/local/AzureRecovery
    
    src_distro=$($script_dir/OS_details_target.sh "$chroot_path")
    if [[ -z "src_distro" ]]; then
        throw_error $_E_AZURE_SMS_OS_UNSUPPORTED "unknown"
    else
        trace "OS : $src_distro"
    fi
}

unset firmware_type
unset _grub2_efi_path
get_firmware_type()
{
    _grub2_efi_path="$chroot_path/boot/efi/EFI/"

    case "$src_distro" in
        OL7*|RHEL6*|RHEL7*|RHEL8*)
            _grub2_efi_path="${_grub2_efi_path}redhat"
            ;;
        CENTOS7*|CENTOS8*)
            _grub2_efi_path="${_grub2_efi_path}centos"
            ;;
        SLES11*|SLES12*)
            _grub2_efi_path="${_grub2_efi_path}opensuse"
            ;;
        UBUNTU*)
            _grub2_efi_path="${_grub2_efi_path}ubuntu"
            ;;
        DEBIAN*)
            _grub2_efi_path="${_grub2_efi_path}debian"
            ;;
        *)
            echo "Unsupported OS version for Migration - $src_distro "
            ;;
    esac

    firmware_type="BIOS"
    if [[ -d $_grub2_efi_path ]]; then
        if [[ -f "$_grub2_efi_path/grub.conf" ]] || [[ -f "$_grub2_efi_path/menu.lst" ]] || [[ -f "$_grub2_efi_path/grub.cfg" ]]; then
            firmware_type="UEFI"
            echo "Grub.cfg path in case of UEFI is: $_grub2_efi_path"
        fi
    else
        echo "Default grub path applicable in case of BIOS"
    fi
}

#@1 - Source file path
#@2 - Target file path
copy_file()
{
    local _source_=$1
    local _target_=$2

    /bin/cp -f $_source_ $_target_
    
    return $?
}

# Recursively copy the folder and contents
function CopyDirectory
{
    if [ -d "$1" ]; then
        /bin/cp -r $1 $2
    else
        echo "Folder $1 is absent. Copy failed."
    fi
    return $_SUCCESS_
}

_BCK_DIR_="azure_sms_bck"
_BCK_EXT_=".bck_azure_sms"
#@1 - File path
backup_file()
{
    local _source_=$1
    local _target_="${_source_}${_BCK_EXT_}"
    
    [[ -f $_source_ ]] || { echo "$_source_ file not found."; return 1; }
    [[ -f $_target_ ]] && { echo "$_target_ already exist."; return 1; }
    
    copy_file $_source_ $_target_
    if [[ $? -ne 0 ]]; then
        # We ignore error in copy step for migration.
        # But log a trace so it shows up in logs.
        trace "WARNING: Could not backup file $1."
    fi

    return $?
}

#@1 - File path
move_to_backup()
{
    local _source_=$1
    local _target_="${_source_}${_BCK_EXT_}"
    
    [[ $_source_ =~ .*${_BCK_EXT_}$ ]] && {
        echo "$_source_ is a backup file.";
        return 1;
    }
    
    [[ -f $_source_ ]] || { 
        echo "$_source_ file not found.";
        return 1;
    }
    
    mv -f $_source_ $_target_
    return $?
}

#@1 - File path
#@2 - Backup directory (optional)
move_to_backup_dir()
{
    [[ -z $1 ]] && return 0
    
    local _source_=$1
    [[ -f $_source_ ]] || {
        echo "File $_source_ not found"
        return 1;
    }
    
    local _target_dir_=$2
    [[ -z $_target_dir_ ]] && _target_dir_="$(dirname $_source_)/$_BCK_DIR_"
    
    [[ -d $_target_dir_ ]] || {
        echo "Creating backup directory $_target_dir_"
        mkdir $_target_dir_
    }
    
    [[ -d $_target_dir_ ]] || {
        echo "Could not create backup directory $_target_dir_"
        return 1;
    }
    
    mv -f $_source_ $_target_dir_
    return $?
}

#@1 - Tool name
verify_tools()
{
    [[ -z "$1" ]] && return 0
    
    for tool_name in $1
    do
        trace "Looking for the tool $tool_name"
        chroot $chroot_path which $tool_name
        if [[ $? -ne 0 ]] ; then
            throw_error $_E_AZURE_SMS_TOOLS_MISSING $tool_name
        else
            trace "$tool_name is available on source."
        fi
    done
    
    return 0
}

#@1 - Kernel version
#@2 - Module list
verify_kernel_modules()
{
    [[ -z "$1" ]] && return 1
    [[ -z "$2" ]] && return 0
    
    local kernel_name="$1"
    for $module_name in $2
    do
        chroot $chroot_path modinfo -k "$kernel_name" $module_name
        if [[ $? -ne 0 ]] ; then
            throw_error $_E_AZURE_SMS_HV_DRIVERS_MISSING $kernel_name
        fi
    done
    
    return 0
}

#@1 - options to remove
#@2 - file path
#@3 - command prefix
remove_cmd_options()
{
    [[ -z "$1" ]] && return 1
    [[ -z "$2" ]] && return 1
    [[ -z "$3" ]] && return 1
    
    local _opts_=$1
    local _file_=$2
    local _cmd_=$3
    
    trace "Removing [${_opts_}] options from $_file_" 
    for _opt_ in $_opts_; do
        sed -i --follow-symlinks "/^[[:space:]]*${_cmd_}.*[[:space:]]root=.*/s/[[:space:]]${_opt_}[[:space:]]*/ /" $_file_
    done
    
    return 0
}

#@1 - options to add
#@2 - file path
#@3 - command prefix
add_cmd_options()
{
    [[ -z "$1" ]] && return 1
    [[ -z "$2" ]] && return 1
    [[ -z "$3" ]] && return 1
    
    local _opts_=$1
    local _file_=$2
    local _cmd_=$3
    
    trace "Adding [${_opts_}] options to $_file_" 
    for _opt_ in $_opts_; do
        if grep -q "^[[:space:]]*${_cmd_}.*[[:space:]]root=.*[[:space:]]${_opt_}\>.*" $_file_; then
            trace "$_opt_ already present in grub command line."
            continue
        fi
        
        sed -i --follow-symlinks "s/\(^[[:space:]]*${_cmd_}.*[[:space:]]root=.*\)\($\)/\1 ${_opt_}\2/" $_file_
    done
    
    return 0
}

#@1 - File name
#@2 - Setting name
#@3 - Setting value
apend_config_setting_value()
{
    if grep -q "\<${2}\>[[:space:]]*=.*\<${3}\>.*" $1 ; then
        # Setting key with value already present.
        return 0
    elif grep -q "\<${2}\>[[:space:]]*=.*" $1 ; then
        # setting key present but not the value, append it.
        sed -i --follow-symlinks "s/\(\<${2}\>[[:space:]]*=[[:space:]]*[\"]\?\)\(.*$\)/\1${3} \2/" $1
    else
        # Setting key not found, adding the setting key=value
        echo "${2}=\"${3}\"" >> $1
    fi
    
    return 0
}

#@1 - Grub command options
#@2 - Grub command setting name
#@3 - Grub command configuration file path
add_grub2_config_options()
{
    local grub_cmd_setting=$2
    local grub_conf_file=$3
    [[ -z $grub_cmd_setting ]] && grub_cmd_setting="GRUB_CMDLINE_LINUX"
    [[ -z $grub_conf_file ]] && grub_conf_file="$chroot_path/etc/default/grub"
    
    for _opt_ in $1; do
        apend_config_setting_value $grub_conf_file $grub_cmd_setting $_opt_
    done
    
    return 0
}

#@1 - File name
#@2 - Setting name
#@3 - Setting value
remove_config_setting_value()
{
    if grep -q "\<$2\>[[:space:]]*=.*\<$3\>.*" $1 ; then
        sed -i --follow-symlinks "s/\(\<$2\>[[:space:]]*=.*\)\<$3\>\(.*\)/\1\2/" $1
    else
        echo "Value \"$3\" not found for the $2."
        return 1
    fi
    return 0
}

#@1 - Setting name
#@2 - File name
comment_config_setting()
 {
    local _setting_line=$(sed -n "/$1/=" $2)
    # Find line number containing SettingName and comment it.
    if [[ ! -z $_setting_line ]]; then
        sed -i "$_setting_line s/^/#/" $2
        echo "Entry $1 has been commented out from $2"
    else
        echo  "Entry $1 not found in file $2"
    fi
 }

#@1 - File name
#@2 - Setting name
#@3 - Setting value
update_config_value()
{
    _config_file_="$1"
    _setting_name_="$2"
    _setting_value_="$3"

    if grep -q "^$2=$3" $1 ; then
        echo "$2=$3 config value is already in place."
    elif grep -q "^$2=.*" $1 ; then
        sed -i --follow-symlinks "s/\(^$2=\)\(.*\?\)/\1$3/" $1
    else
        # Setting key not found, adding the setting key=value
        echo "$2=$3" >> $1
    fi
}

#@1 - File name
#@2 - Setting name
#@3 - Setting value
update_config_value_if_exists()
{
    _config_file_="$1"
    _setting_name_="$2"
    _setting_value_="$3"

    if grep -q "^$2=$3" $1 ; then
        echo "$2=$3 config value is already in place."
    elif grep -q "^$2=.*" $1 ; then
        sed -i --follow-symlinks "s/\(^$2=\)\(.*\?\)/\1$3/" $1
    else
        echo "$2 setting not found, nothing to update."
    fi
}

#@1 - File name
#@2 - Setting name
remove_config_entry()
{
    _config_file_="$1"
    _setting_name_="$2"

    if grep -q "^$2=.*" $1 ; then
        sed -i --follow-symlinks "/^$2=/d" $1
    else
        echo "$2 config setting not found, nothing to remove."
    fi
}

#@1 - Grub command options
#@2 - Grub command setting name
#@3 - Grub command configuration file path
remove_grub2_config_options()
{
    local grub_cmd_setting=$2
    local grub_conf_file=$3
    [[ -z $grub_cmd_setting ]] && grub_cmd_setting="GRUB_CMDLINE_LINUX"
    [[ -z $grub_conf_file ]] && grub_conf_file="$chroot_path/etc/default/grub"
    
    for _opt_ in $1; do
        remove_config_setting_value $grub_conf_file $grub_cmd_setting $_opt_
    done
    
    return 0
}

#@1 - options to remove
#@2 - grub file path
remove_grub_cmd_options()
{
    [[ -z "$1" ]] && return 1
    
    local _grub_conf_file="$2"
    if [[ -z "$2" ]]; then
        if [ "$firmware_type" = "UEFI" ]; then
            _grub_conf_file="$_grub2_efi_path/grub.conf"
        else
            _grub_conf_file="$chroot_path/grub/grub.conf"
        fi
    fi
    
    
    remove_cmd_options "$1" "$_grub_conf_file" "kernel" 
    return $?
}

#@1 - options to remove
#@2 - grub file path
remove_grub2_cmd_options()
{
    [[ -z "$1" ]] && return 1
    
    local _grub2_conf_file="$2"
    if [[ -z "$2" ]]; then
        if [ "$firmware_type" = "UEFI" ]; then
            _grub_conf_file="$_grub2_efi_path/grub.cfg"
        else
            _grub2_conf_file="$chroot_path/boot/grub2/grub.cfg"
        fi
    fi
     
    remove_cmd_options "$1" "$_grub2_conf_file" "linux"
    return $?
}

#@1 - options to add
#@2 - grub file path
add_grub_cmd_options()
{
    [[ -z "$1" ]] && return 1
    
    local _grub_conf_file="$2"
    if [[ -z "$2" ]]; then
        if [ "$firmware_type" = "UEFI" ]; then
            _grub_conf_file="$_grub2_efi_path/grub.conf"
        else
            _grub_conf_file="$chroot_path/grub/grub.conf"
        fi
    fi
    
    add_cmd_options "$1" "$_grub_conf_file" "kernel"
    return $?
}

#@1 - options to add
#@2 - grub file path
add_grub2_cmd_options()
{
    [[ -z "$1" ]] && return 1
    
    local _grub2_conf_file="$2"
    if [[ -z "$2" ]]; then
        if [ "$firmware_type" = "UEFI" ]; then
            _grub_conf_file="$_grub2_efi_path/grub.cfg"
        else
            _grub2_conf_file="$chroot_path/boot/grub2/grub.cfg"
        fi
    fi    

    add_cmd_options "$1" "$_grub2_conf_file" "linux"
    return $?
}

#@1 - kernel version
is_kernel_in_use()
{
    [[ -z "$1" ]] && return 1
    
    local kernel_version=$1
    local grub_conf_files="$chroot_path/boot/grub/menu.lst \
            $chroot_path/boot/grub/grub.cfg \
            $chroot_path/boot/grub2/grub.cfg \
            $_grub2_efi_path/menu.lst \
            $_grub2_efi_path/grub.conf \
            $_grub2_efi_path/grub.cfg"
    
    for grub_file in $grub_conf_files
    do
        if [[ -f $grub_file ]]; then
            grep -q "\<initrd.*[[:space:]].*/initr.*${kernel_version}.*" $grub_file
            return $?
        fi
    done
    
    return 1
}

mount_runtime_partitions()
{
    for partition in proc dev sys
    do
        mount --bind "/$partition" "$chroot_path/$partition"
    done
}

remove_persistent_net_rules()
{
    local _files="${chroot_path}/lib/udev/rules.d/75-persistent-net-generator.rules \
    ${chroot_path}/etc/udev/rules.d/70-persistent-net.rules"
    
    for _file in $_files
    do
        backup_file $_file
        rm -f $_file
    done
}

reset_persistent_net_gen_rules()
{
    move_to_backup "${chroot_path}/etc/udev/rules.d/75-persistent-net-generator.rules"
    chroot ${chroot_path} ln -f -s /dev/null /etc/udev/rules.d/75-persistent-net-generator.rules
}

remove_network_manager_rpm()
{
    trace "Removing persistent net rules"
    
    reset_persistent_net_gen_rules
    
    backup_file "${chroot_path}/etc/udev/rules.d/70-persistent-net.rules"
    rm -f ${chroot_path}/etc/udev/rules.d/70-persistent-net.rules
    
    echo "Removing NetworkManager ..."
    chroot ${chroot_path} rpm -e --nodeps NetworkManager
    
    # Remove network manager binary if exist.
    local net_mngr_file="${chroot_path}/etc/init.d/NetworkManager"
    if [[ -f $net_mngr_file ]]; then
        rm -f $net_mngr_file
    fi
}

update_network_dhcp_file()
{
    local dhcp_file="${chroot_path}/etc/sysconfig/network/dhcp"
    if [[ -f $dhcp_file ]]; then
        update_config_value $dhcp_file DHCLIENT_SET_HOSTNAME '"no"'
    fi
}

update_network_file()
{
    local network_file="${chroot_path}/etc/sysconfig/network"
    if [[ -f $network_file ]]; then
        backup_file $network_file
        update_config_value $network_file "NETWORKING" "yes"
        remove_config_entry $network_file "GATEWAY"
        update_config_value_if_exists $network_file "GATEWAYDEV" "eth0"
    else
        echo "NETWORKING=yes" > $network_file
        echo "HOSTNAME=localhost.localdomain" >> $network_file
    fi
}

#@1 - kernel image name or path
is_kernel_image_in_use()
{
    [[ -z "$1" ]] && return 1
    
    local kernel_image=$(basename $1)
    local grub_conf_files="$chroot_path/boot/grub/menu.lst \
            $chroot_path/boot/grub/grub.conf \
            $chroot_path/boot/grub/grub.cfg \
            $chroot_path/boot/grub2/grub.cfg \
            $_grub2_efi_path/menu.lst \
            $_grub2_efi_path/grub.conf \
            $_grub2_efi_path/grub.cfg"
    
    for grub_file in $grub_conf_files
    do
        if [[ -f $grub_file ]] && 
        grep -q "\<initrd.*[[:space:]].*/${kernel_image}\>" $grub_file; then
            trace "${kernel_image} found in $grub_file"
            return 0
        fi
    done
    
    return 1
}

#@1 - module name
verify_hv_drivers_in_module()
{
    [[ -z "$1" ]] && return 0
    
    local kernel_version=$1
    trace "Checking hyper-v drivers in the kernel $kernel_version"
    
    for driver_name in hv_vmbus hv_storvsc hv_netvsc
    do
        chroot $chroot_path modinfo -k $kernel_version $driver_name
        [[ $? -ne 0 ]] && throw_error $_E_AZURE_SMS_HV_DRIVERS_MISSING $kernel_version
        
        trace "$driver_name available in the kernel."
    done
    
    return 0
}

#@1 - kernel image file path
verify_hv_drivers_in_kernel_image()
{
    [[ -z "$1" ]] && return 1
    
    local kernel_image_name=$(basename $1)
    local ls_image=$(chroot $chroot_path lsinitrd /boot/$kernel_image_name)
    
    trace "Checking hyper-v drivers in the image $kernel_image_name"
    
    for hv_driver in hv_vmbus hv_storvsc hv_netvsc
    do
        echo $ls_image | grep -q "${hv_driver}.ko"
        [[ $? -ne 0 ]] && return 1
    done
    
    trace "hyper-v drivers present in $kernel_image_name"
    
    return 0
}

#@1 - Kernel version
#@2 - Kernel image file path
generate_initrd_image()
{
    [[ -z "$1" ]] && return 1
    [[ -z "$2" ]] && return 1
    
    local hv_drivers="hv_vmbus hv_storvsc hv_netvsc"
    local kernel_image=$(basename $2)
    local kernel_image_path=/boot/$kernel_image
    
    trace "taking image backup..."
    backup_file "$chroot_path/boot/$kernel_image"

    trace "start re-generating kernel image $kernel_image_path with version $1 ..."
    chroot $chroot_path dracut -f --add-drivers "$hv_drivers" $kernel_image_path $1
    if [[ $? -ne 0 ]]; then
        # We throw an error in dracut step for migration.
        # TODO: Propagate this error up and handle so Migration passes but user\CSS knows step to take.
        # This will be a multi phase \ step error code bitmap. Since steps are independent of 
        # each other.
        trace "WARNING: Could not perform dracut and generate image step."
        return $_E_AZURE_SMS_INITRD_IMAGE_GENERATION_FAILED
    else
        trace "successfully generated the image!"
    fi
    
    return 0
}

#@1 - grub options to add
#@2 - grub options to remove
modify_grub_config()
{
    local _grub_path="$chroot_path/boot/grub/menu.lst"
    local opts_to_comment="password --encrypted"

    if [ "$firmware_type" = "UEFI" ]; then
        if [ -f "$_grub2_efi_path/grub.conf" ]; then
            _grub_path="$_grub2_efi_path/grub.conf"
        elif [ -f "$_grub2_efi_path/menu.lst" ]; then
            _grub_path="$_grub2_efi_path/menu.lst"
        elif [ -f "$_grub2_efi_path/grub.cfg" ]; then
            _grub_path="$_grub2_efi_path/grub.cfg"
        fi
    fi

    [[ ! -f $_grub_path ]] && _grub_path="$chroot_path/boot/grub/grub.conf"
    echo "Grub File: $_grub_path"

    [[ ! -f $_grub_path ]] && throw_error $_E_AZURE_SMS_CONF_MISSING $(basename $_grub_path)
        
    remove_grub_cmd_options "$opts_to_remove" $_grub_path
    add_grub_cmd_options "$opts_to_add" $_grub_path
    comment_config_setting "$opts_to_comment" $_grub_path
}

#@1 - grub options to add
#@2 - grub config setting name
#@3 - grub options to remove
modify_grub2_config()
{
    local _grub2_path="$chroot_path/boot/grub2/grub.cfg"

    if [ "$firmware_type" = "UEFI" ]; then
        if [ -f "$_grub2_efi_path/grub.cfg" ]; then
            _grub2_path="$_grub2_efi_path/grub.cfg"
        elif [ -f "$_grub2_efi_path/menu.lst" ]; then
            _grub2_path="$_grub2_efi_path/menu.lst"
        elif [ -f "$_grub2_efi_path/grub.conf" ]; then
            _grub2_path="$_grub2_efi_path/grub.conf"
        fi
    fi

    
    echo "Grub File: $_grub2_path Setting Name: $2 Add: $1 Remove: $3"
    [[ ! -f $_grub2_path ]] && _grub2_path="$chroot_path/boot/grub/grub.cfg"    
    [[ ! -f $_grub2_path ]] && throw_error $_E_AZURE_SMS_CONF_MISSING $(basename $_grub2_path)
    
    if [[ ! -z "$3" ]]; then
        remove_grub2_cmd_options "$3" $_grub2_path
        remove_grub2_config_options "$3" $2
    fi
    
    if [[ ! -z "$1" ]]; then
        add_grub2_config_options "$1" "$2"
        add_grub2_cmd_options "$1" $_grub2_path
    fi

    local opts_to_comment="password --encrypted"
    comment_config_setting "$opts_to_comment" $_grub2_path
}

install_linux_guest_agent()
{
    enable_installga_service

    linuxgadir="/usr/local/AzureRecovery/WALinuxAgentASR/WALinuxAgent-master"
    targetgadir="$chroot_path/var/WALinuxAgentASR/"

    if [[ ! -d "$linuxgadir" ]]; then
        trace "Folder containing Guest agent binaries is not present."
        return 1;
    fi

    if [[ ! -d $targetgadir ]]; then
        trace "Target guest agent folder doesn't exist. Creating $targetgadir"
        mkdir $targetgadir
    fi

    CopyDirectory $linuxgadir $targetgadir
    if [[ $? -ne 0 ]]; then
        trace "Could not copy LinuxGuestAgent installation directory to target location."
        return 1;
    fi

    copy_file "/usr/local/AzureRecovery/InstallLinuxGuestAgent.sh" "$chroot_path/var/InstallLinuxGuestAgent.sh"
    if [[ $? -ne 0 ]]; then
        trace "Could not copy LinuxGuestAgent installation file."
        return 1;
    fi

    copy_file "/usr/local/AzureRecovery/PythonSetupPrereqs.py" "$chroot_path/var/PythonSetupPrereqs.py"
    if [[ $? -ne 0 ]]; then
        trace "Could not copy python setup prereqs file."
        # Don't fail.
    fi
}

install_custom_script_agent()
{
    enable_custom_script_service

    customscriptdir="/usr/local/AzureRecovery/user_files"
    targetscriptdir="$chroot_path/var/"

    if [[ ! -d "$customscriptdir" ]]; then
        trace "Folder containing custom script is not present."
        return 1;
    fi

    if [[ ! -d $targetscriptdir ]]; then
        trace "Target custom script folder doesn't exist. Creating $targetscriptdir"
        mkdir $targetscriptdir
    fi

    CopyDirectory $customscriptdir $targetscriptdir
    if [[ $? -ne 0 ]]; then
        trace "Could not copy custom script installation directory to target location."
        return 1;
    fi

}

configure_dhcp_rhel()
{
    local ifcfg_dir="$chroot_path/etc/sysconfig/network-scripts"
    
    # move the existing cscfg files to backup.
    for _file in $(ls $ifcfg_dir/ifcfg-*)
    do
        local ifcfg_file=$(basename $_file)
        
        # ignore loop back ifcfg.
        [[ "$ifcfg_file" = "ifcfg-lo" ]] && continue
        
        ifcfg_file="$ifcfg_dir/$ifcfg_file"
        move_to_backup_dir $ifcfg_file
    done
    
    local default_dhcp_cscfg="$ifcfg_dir/ifcfg-eth0"
    echo "DEVICE=eth0" > $default_dhcp_cscfg
    echo "ONBOOT=yes" >> $default_dhcp_cscfg

    user_disable_dhcp="EnableDHCP:false"
    if [[ $custom_config_settings =~ .*$user_disable_dhcp.* ]]; then
        echo "DHCP=no" >> $default_dhcp_cscfg
        echo "BOOTPROTO=none" >> $default_dhcp_cscfg
        trace "User Opted to turn OFF DHCP."
    else
        echo "DHCP=yes" >> $default_dhcp_cscfg
        echo "BOOTPROTO=dhcp" >> $default_dhcp_cscfg
        trace "User opted to keep DHCP ON"
    fi


    echo "TYPE=Ethernet" >>  $default_dhcp_cscfg
    echo "USERCTL=no" >>  $default_dhcp_cscfg
    echo "PEERDNS=yes" >>  $default_dhcp_cscfg
    echo "IPV6INIT=no" >> $default_dhcp_cscfg
}

configure_dhcp_sles()
{
    local ifcfg_dir="$chroot_path/etc/sysconfig/network"
    
    # move the existing cscfg files to backup.
    for _file in $(ls $ifcfg_dir/ifcfg-*)
    do
        local ifcfg_file=$(basename $_file)
        
        # ignore loop back ifcfg.
        [[ "$ifcfg_file" = "ifcfg-lo" ]] && continue
        
        ifcfg_file="$ifcfg_dir/$ifcfg_file"
        move_to_backup_dir $ifcfg_file
    done
    
    local default_dhcp_cscfg="$ifcfg_dir/ifcfg-eth0"
    user_disable_dhcp="EnableDHCP:false"
    if [[ $custom_config_settings =~ .*$user_disable_dhcp.* ]]; then
        echo "BOOTPROTO=none" >> $default_dhcp_cscfg
        trace "User Opted to turn OFF DHCP."
    else
        echo "BOOTPROTO=dhcp" >> $default_dhcp_cscfg
        trace "User opted to keep DHCP ON"
    fi
    echo "MTU='' " >> $default_dhcp_cscfg
    echo "REMOTE_IPADDR='' " >>$default_dhcp_cscfg
    echo "STARTMODE='onboot'" >>$default_dhcp_cscfg
}

configure_dhcp_ubuntu()
{
    _interfaces_file="$chroot_path/etc/network/interfaces"
    
    # Backup the original interfaces file
    backup_file "$_interfaces_file"
    
    # Create new interfaces file
    echo "# The loopback network interface" > $_interfaces_file
    echo "auto lo" >> $_interfaces_file
    echo "iface lo inet loopback" >> $_interfaces_file
    echo "" >> $_interfaces_file
    echo "# The primary network interface" >> $_interfaces_file
    echo "auto eth0" >> $_interfaces_file
    
    user_disable_dhcp="EnableDHCP:false"
    if [[ $custom_config_settings =~ .*$user_disable_dhcp.* ]]; then
        echo "iface eth0 inet none" >> $_interfaces_file
        trace "User Opted to turn OFF DHCP."
    else
        echo "iface eth0 inet dhcp" >> $_interfaces_file
        trace "User opted to keep DHCP ON"
    fi
}

create_dhcp_netplan_config_and_apply()
{
    # As a workaround, taking a random filename for netplan dhcp configuration.
    # As soon as Azure Compute publishes steps for preparing Ubuntu 18.04 LTS
    # we will follow those instructions to prepare netplan configuration.
    local dhcp_netplan_file="$chroot_path/etc/netplan/50-azure_migrate_dhcp.yaml"
    if [[ -f $dhcp_netplan_file ]]; then
        echo "DHCP netplan configuration for Azure migrate is already exist."
        return;
    fi
    
    echo "# This is generated for Azure SMS to make NICs DHCP in Azure." > $dhcp_netplan_file
    echo "network:" >> $dhcp_netplan_file
    echo "    version: 2" >> $dhcp_netplan_file
    echo "    ethernets:" >> $dhcp_netplan_file
    echo "        ephemeral:" >> $dhcp_netplan_file

    user_disable_dhcp="EnableDHCP:false"
    if [[ $custom_config_settings =~ .*$user_disable_dhcp.* ]]; then
        echo "            dhcp4: false" >> $dhcp_netplan_file
        trace "User Opted to turn OFF DHCP."
    else
        echo "            dhcp4: true" >> $dhcp_netplan_file
        trace "User opted to keep DHCP ON"
    fi
    echo "            match:" >> $dhcp_netplan_file
    echo "                driver: hv_netvsc" >> $dhcp_netplan_file
    echo "                name: '!eth0'" >> $dhcp_netplan_file
    echo "            optional: true" >> $dhcp_netplan_file
    echo "        hotpluggedeth0:" >> $dhcp_netplan_file
    echo "            dhcp4: true" >> $dhcp_netplan_file

    if [[ $custom_config_settings =~ .*$user_disable_dhcp.* ]]; then
        echo "            dhcp4: false" >> $dhcp_netplan_file
        trace "User Opted to turn OFF DHCP."
    else
        echo "            dhcp4: true" >> $dhcp_netplan_file
        trace "User opted to keep DHCP ON"
    fi
    echo "            match:" >> $dhcp_netplan_file
    echo "                driver: hv_netvsc" >> $dhcp_netplan_file
    echo "                name: 'eth0'" >> $dhcp_netplan_file
    
    trace "Applying the dhcp netplan configuration... "
    chroot $chroot_path netplan apply
    if [[ $? -eq 0 ]]; then
        trace "netplan with dhcp settings applied!"
    else
        trace "WARNING: netplan couldn't apply dhcp settings."
    fi
}

enable_network_service()
{
    trace "Making network service to start at boot time."
    
    case $src_distro in
        RHEL6*|CENTOS6*|OL6*)
            chroot $chroot_path chkconfig network on
            ;;
        RHEL7*|CENTOS7*|RHEL8*|CENTOS8*|OL7*)
            chroot $chroot_path systemctl enable network
            ;;
        *)
            # For rest no operation.
            ;;
        esac
}

verify_src_os_version()
{
    find_src_distro
    
    local supported_distros="OL6 OL7 \
          RHEL6 RHEL7 RHEL8 \
          CENTOS6 CENTOS7 CENTOS8 \
          SLES11 SLES12 \
          UBUNTU14 UBUNTU16 UBUNTU18 \
          DEBIAN7 DEBIAN8 DEBIAN9"
          
    for distro in $supported_distros
    do
        [[ "$src_distro" =~ "${distro}-"* ]] && [[ "$src_distro" == *"-64" ]] && return
    done
    
    throw_error $_E_AZURE_SMS_OS_UNSUPPORTED $src_distro
}

verify_requited_tools()
{
    local tools_to_verify=""
    
    case "$src_distro" in
    OL6*|OL7*|RHEL6*|RHEL7*|RHEL8*|CENTOS6*|CENTOS7*|CENTOS8*|SLES11*|SLES12*)
        tools_to_verify="lsinitrd dracut modinfo dhclient"
        ;;
    SLES11*)
        # dracut is not available for SLES11,
        # mkinitrd will be used to generate kernel image.
        tools_to_verify="lsinitrd mkinitrd modinfo dhclient"
        ;;
    UBUNTU14*|UBUNTU16*|UBUNTU18*|DEBIAN*)
        # Supported Ubuntu & Debian distros will have
        # hyper-v drivers build-in to the kernel image,
        # so the relevant tools won't be needed for these
        # distros migration steps hence not including them
        # in the list.
        tools_to_verify="dhclient"
        ;;
    *)
        throw_error $_E_AZURE_SMS_OS_UNSUPPORTED $src_distro
        ;;
    esac

    verify_tools "$tools_to_verify"
}

verify_uefi_bootloader_files()
{
    config_file_name=""
    bootloader_folder_path="$chroot_path/boot/efi/EFI/boot"

    if [ "$firmware_type" = "UEFI" ]; then
        if [ ! -f "$_grub2_efi_path/bootx64.efi" ]; then
            if [ -f "$_grub2_efi_path/shimx64.efi" ]; then
                copy_file "$_grub2_efi_path/shimx64.efi" "$_grub2_efi_path/bootx64.efi"
            elif [ -f "$_grub2_efi_path/grubx64.efi" ]; then
                copy_file "$_grub2_efi_path/grubx64.efi" "$_grub2_efi_path/bootx64.efi"
            elif [ -f "$_grub2_efi_path/grub.efi" ]; then
                copy_file "$_grub2_efi_path/grub.efi" "$_grub2_efi_path/bootx64.efi"
            else
                if [ ! -d "$bootloader_folder_path" ] || [ ! -f "$bootloader_folder_path/bootx64.efi" ]; then
                    echo "efi file is absent on source disk which will lead to boot failure in Gen2 vm."
                    exit 1
                fi
            fi
        fi

        if [ -f "$_grub2_efi_path/grub.cfg" ]; then
            config_file_name="grub.cfg"
            copy_file "$_grub2_efi_path/grub.cfg" "$_grub2_efi_path/bootx64.cfg"
        elif [ -f "$_grub2_efi_path/grub.conf" ]; then
            config_file_name="grub.conf"            
            copy_file "$_grub2_efi_path/grub.conf" "$_grub2_efi_path/bootx64.conf"
        else
            echo "grub config file not found in grub folder."
        fi

        # Folder needs to be explicitly added for Ubuntu/Debian/RHEL6/CENTOS6.
        # Checking and adding for other distros too if not added.
        if [ ! -d "$bootloader_folder_path" ]; then
            CopyDirectory "$_grub2_efi_path/" "$bootloader_folder_path"
        else
            trace "BOOT folder is present on the disk."
            if [ ! -f  "$bootloader_folder_path/bootx64.efi" ]; then
                copy_file "$_grub2_efi_path/bootx64.efi" "$bootloader_folder_path/bootx64.efi"
            fi

            # bootx64.conf required for RHEL6/CENTOS6. Copying for other distros too.
            if [ $config_file_name = "grub.cfg" ] && [ ! -f "$bootloader_folder_path/bootx64.cfg" ]; then
                copy_file "$_grub2_efi_path/bootx64.cfg" "$bootloader_folder_path/bootx64.cfg"
            elif [ $config_file_name = "grub.conf" ] && [ ! -f "$bootloader_folder_path/bootx64.conf" ]; then
                copy_file "$_grub2_efi_path/bootx64.conf" "$bootloader_folder_path/bootx64.conf"
            fi
        fi
    else
        trace "Boot folder verification not required for BIOS."
    fi

}

verify_generate_initrd_images()
{
    case "$src_distro" in
    SLES11*)
        # dracut is not available for SLES11,
        # mkinitrd will be used to generate kernel image.
        # TODO: Add support post preview.
        throw_error $_E_AZURE_SMS_OS_UNSUPPORTED $src_distro
        ;;
    UBUNTU14*|UBUNTU16*|UBUNTU18*|DEBIAN*)
        # Supported Ubuntu & Debian distros will have
        # hyper-v drivers build-in to the kernel image,
        # so skipping this step for these distros.
        return 0
        ;;
    *)
        # Will verify and regenerate initrd images for rest
        # of the supported distros, and control won't come
        # this far for unsupported distros.
        ;;
    esac
    
    trace "$(ls -d ${chroot_path}/lib/modules/*)"

    local last_error_in_generate_initrd_image=0
    for mod_path in $(ls -d ${chroot_path}/lib/modules/*)
    do
        [[ ! -d $mod_path ]] && continue
        [[ ! -f $mod_path/modules.dep ]] && continue
        
        local kernel_version=$(basename $mod_path)
        is_kernel_in_use $kernel_version
        if [[ $? -ne 0 ]]; then
            trace "$kernel_version is not in use. Skipping it."
            continue
        fi
        
        # Checking if hyper-v drivers are available
        # in the kernel, if not then error will be thrown.
        verify_hv_drivers_in_module $kernel_version
        
        for kernel_image_file in $(ls ${chroot_path}/boot/initr*${kernel_version}*)
        do
            is_kernel_image_in_use $kernel_image_file
            if [[ $? -ne 0 ]] ; then 
                echo "$kernel_image_file is not in use. Skipping it."
                continue
            fi
            
            verify_hv_drivers_in_kernel_image $kernel_image_file
            [[ $? -eq 0 ]] && continue
            
            trace "Re-generating $kernel_image_file with hyper-v drivers"
            generate_initrd_image $kernel_version $kernel_image_file
            # This will brak the loop immediately.
            # For other drivers there will be no verification.
            last_error_in_generate_initrd_image=$?
        done
    done
    
    # Return error if ay geneate_initd_image filed.
    return $last_error_in_generate_initrd_image
}

set_serial_console_grub_options()
{
    trace "Updating boot grub options to redirect serial console logs ..."
    
    local opts_to_remove="rhgb quiet crashkernel=auto acpi=0"
    local opts_to_add="numa=off console=ttyS0 earlyprintk=ttyS0 rootdelay=300"
    case $src_distro in
    RHEL6*|CENTOS6*|OL6*|SLES11*)
        modify_grub_config "$opts_to_add" "$opts_to_remove"
        ;;
    UBUNTU14*|UBUNTU16*|UBUNTU18*)
        opts_to_add="console=tty1 console=ttyS0,115200n8 earlyprintk=ttyS0,115200 rootdelay=300"
        modify_grub2_config "$opts_to_add" "GRUB_CMDLINE_LINUX_DEFAULT" "$opts_to_remove"
        ;;
    DEBIAN*)
        opts_to_add="console=tty0 console=ttyS0,115200n8 earlyprintk=ttyS0,115200 rootdelay=30"
        modify_grub2_config "$opts_to_add" "GRUB_CMDLINE_LINUX"
        ;;
    SLES12*)
        opts_to_add="console=ttyS0 earlyprintk=ttyS0 rootdelay=300"
        modify_grub2_config "$opts_to_add" "GRUB_CMDLINE_LINUX"
        ;;
    RHEL7*|CENTOS7*|OL7*|RHEL8*|CENTOS8*)
        #Following options are taken from official Azure document for RHEL7.
        #https://docs.microsoft.com/en-us/azure/virtual-machines/troubleshooting/serial-console-grub-single-user-mode#grub-access-in-rhel
        #and 
        #https://docs.microsoft.com/en-us/azure/virtual-machines/troubleshooting/serial-console-grub-proactive-configuration
        opts_to_add="console=tty1 console=ttyS0,115200n8 earlyprintk=ttyS0,115200 rootdelay=300 net.ifnames=0"
        modify_grub2_config "$opts_to_add" "GRUB_CMDLINE_LINUX" "$opts_to_remove"
        modify_grub2_config "serial console" "GRUB_TERMINAL_OUTPUT" ""
        modify_grub2_config "serial" "GRUB_SERIAL_COMMAND" ""
        # This value should be Serial console. But our text replacement code reverses order
        # So writing console serial which should become serial console when committed.
        modify_grub2_config "console serial" "GRUB_TERMINAL" ""
        ;;
    *)
        throw_error $_E_AZURE_SMS_OS_UNSUPPORTED $src_distro
        ;;
    esac
    trace "Successfully updated boot grub options!"
}

enable_systemd_on_startupscipt()
{
    local _systemd_cofig_file="$chroot_path/lib/systemd/system/${_AM_STARTUP_}.service"
    if [[ ! -d $chroot_path/lib/systemd ]]; then
        _systemd_cofig_file="$chroot_path/usr/lib/systemd/system/${_AM_STARTUP_}.service"
    fi
    
    if [[ -f $_systemd_cofig_file ]]; then
        trace "Startup script is already configured!"
        return 0
    fi
        
    echo "[Unit]" > $_systemd_cofig_file
    echo "Description=Azure migrate startup script to create nic config." >> $_systemd_cofig_file
    echo "After=network.target" >> $_systemd_cofig_file
    echo "" >> $_systemd_cofig_file
    echo "[Service]" >> $_systemd_cofig_file
    echo "ExecStart=${_AM_SCRIPT_DIR_}/${_STARTUP_SCRIPT_} start" >> $_systemd_cofig_file
    echo "" >> $_systemd_cofig_file
    echo "[Install]" >> $_systemd_cofig_file
    echo "WantedBy=default.target" >> $_systemd_cofig_file

    trace "Adding startup script."
    chroot $chroot_path systemctl enable "${_AM_STARTUP_}.service"
    if [[ $? -eq 0 ]]; then
        trace "Successfully added startup script!"
    else
        trace "WARNING: Could not add startup script for DHCP."
    fi

    return 0
}

enable_chkconfig_on_startupscript()
{
    local _chkconfig_startup_file="/etc/init.d/${_AM_STARTUP_}"
    if [[ -h "${chroot_path}$_chkconfig_startup_file" ]]; then
        trace "Startup script is already configured!"
        return;
    fi
    
    local _startup_script_path="${_AM_SCRIPT_DIR_}/${_STARTUP_SCRIPT_}"
    chroot $chroot_path ln -s $_startup_script_path $_chkconfig_startup_file
    if [[ $? -ne 0 ]]; then
        trace "WARNING: Could not create start-up script."
        return 0
    fi
    
    local _config_startup_cmd=""
    if chroot $chroot_path which chkconfig > /dev/null 2>1$ ;then
        _config_startup_cmd="chroot $chroot_path chkconfig --add ${_AM_STARTUP_}"
    elif chroot $chroot_path which update-rc.d > /dev/null 2>1$ ;then
        _config_startup_cmd="chroot $chroot_path update-rc.d ${_AM_STARTUP_} defaults"
    else
        trace "WARNING: No tools found to configure start-up script."
        return 0
    fi
    
    trace "Adding startup script."    
    $_config_startup_cmd > /dev/null 2>&1
    if [[ $? -ne 0 ]]; then
        trace "WARNING: Could not add start-up script."
    else
        trace "Successfully added startup script!"
    fi
    
    return 0
}

create_startup_scripts()
{
    trace "Adding startup script to configure dhcp on migrated azure vm."
    local startup_script_dir=$1
    [[ -d $startup_script_dir ]] || mkdir $startup_script_dir 
    if [[ ! -d $startup_script_dir ]]; then
        trace "WARNING: Cloud not create ${startup_script_dir} for startup script."
        return 1
    fi
    
    local working_dir=$(cd $(dirname "$0") > /dev/null && pwd)
    [[ -d "$working_dir" ]] || working_dir=/usr/local/AzureRecovery
    
    copy_file "$working_dir/$_FIX_DHCP_SCRIPT_" "${startup_script_dir}/${_FIX_DHCP_SCRIPT_}"
    if [[ $? -ne 0 ]]; then
        trace "WARNING: Cloud not copy scripts to startup script directory."
        return 1
    fi
    
    # Startup script file
    local _startup_script_path="$startup_script_dir/$_STARTUP_SCRIPT_"
    echo "#!/bin/bash
# This is for RHEL systems
# processname: ${_AM_STARTUP_}
# chkconfig: 2345 90 90
# description: Azure migrate startup script to configure networks

### BEGIN INIT INFO
# Provides: ${_AM_STARTUP_}
# Required-Start: \$local_fs
# Required-Stop: \$local_fs
# X-Start-Before: \$network
# X-Stop-After: \$network
# Default-Start: 2 3 4 5
# Default-Stop: 0 1 6
# Description: Azure migrate startup script to configure networks
### END INIT INFO " > $_startup_script_path

    echo 'case "$1" in' >> $_startup_script_path
    echo "start)" >> $_startup_script_path
    echo "${_AM_SCRIPT_DIR_}/${_FIX_DHCP_SCRIPT_} > ${_AM_SCRIPT_LOG_FILE_} 2>&1 ;;" >> $_startup_script_path
    echo "*)" >> $_startup_script_path
    echo ";;" >> $_startup_script_path
    echo "esac" >> $_startup_script_path
    echo "" >> $_startup_script_path
    
    # Execute permissions for the scripts
    chmod +x $startup_script_dir/*
    return $?
}

add_startup_script_for_dhcp()
{
    local startup_script_dir="${chroot_path}${_AM_SCRIPT_DIR_}"
    create_startup_scripts $startup_script_dir
    if [[ $? -ne 0 ]]; then
        trace "WARNING: Skip configuring startup script."
        return 0;
    fi
    
    case $src_distro in
        RHEL6*|CENTOS6*|OL6*|SLES11*|UBUNTU14*|DEBIAN7*)
            enable_chkconfig_on_startupscript
            ;;
        SLES12*|DEBIAN8*|DEBIAN9*|UBUNTU16*|RHEL7*|CENTOS7*|OL7*|RHEL8*|CENTOS8*)
            enable_systemd_on_startupscipt
            ;;
        *)
            trace "WARNING: Unknown distro '$src_distro' to configure startup script."
            
            trace "Removing startup script directory '$startup_script_dir'."
            rm -rf $startup_script_dir
            ;;
    esac
}

enable_installga_service()
{
    # Startup script to install azure guest agent.
    local asr_installga_exfile_path="usr/local/${_AM_INSTALLGA_}/asr.installga"

    # Create a directory if it doesn't exist.
    if [[ ! -d "$chroot_path/usr/local/${_AM_INSTALLGA_}" ]]; then
        trace "Creating a new directory /usr/local/${_AM_INSTALLGA_}"
        mkdir "$chroot_path/usr/local/${_AM_INSTALLGA_}"
    fi
    
    if [[ -f $chroot_path/$asr_installga_exfile_path ]]; then
        trace "/usr/local/${_AM_INSTALLGA_}/asr.installga exists. Deleting the file."
        rm $chroot_path/$asr_installga_exfile_path
    fi
 
    # Write execution commands for asr.installga executable.
    trace "Creating asr.installga for execution during boot."

    echo "#!/bin/bash" >> $chroot_path/$asr_installga_exfile_path
    echo "#This file is generated for execution during boot" >> $chroot_path/$asr_installga_exfile_path
    echo "bash /var/InstallLinuxGuestAgent.sh" >> $chroot_path/$asr_installga_exfile_path
    echo "return 0" >> $chroot_path/$asr_installga_exfile_path

    # Add executable permissions.
    chmod +x $chroot_path/$asr_installga_exfile_path

    # Check for systemd path. The path may vary among linux distros.
    local _systemd_config_file="$chroot_path/lib/systemd/system/${_AM_INSTALLGA_}.service"
    if [[ ! -d $chroot_path/lib/systemd/system ]]; then
        if [[ -d $chroot_path/usr/lib/systemd/system ]]; then
            _systemd_config_file="$chroot_path/usr/lib/systemd/system/${_AM_INSTALLGA_}.service"
        elif [[ -d $chroot_path/etc/systemd/system ]]; then
            _systemd_config_file="$chroot_path/etc/systemd/system/${_AM_INSTALLGA_}.service"
        fi
    fi

    # Delete the file if it already exists
    if [[ -f $_systemd_config_file ]]; then
        trace "$_systemd_config_file exists. Deleting the file."
        rm $_systemd_config_file
    fi

    trace "Creating systemd config file. $_systemd_config_file"

    echo "[Unit]" >> $_systemd_config_file
    echo "Description=Install Azure Linux Guest agent startup script by ASR" >> $_systemd_config_file
    echo "ConditionPathExists=/$asr_installga_exfile_path" >> $_systemd_config_file
    echo "" >> $_systemd_config_file
    echo "[Service]" >> $_systemd_config_file
    echo "Type=forking" >> $_systemd_config_file
    echo "ExecStart=/$asr_installga_exfile_path start" >> $_systemd_config_file
    echo "TimeoutSec=0" >> $_systemd_config_file
    echo "StandardOutput=tty" >> $_systemd_config_file
    echo "RemainAfterExit=yes" >> $_systemd_config_file
    echo "SysVStartPriority=99" >> $_systemd_config_file
    echo "" >> $_systemd_config_file
    echo "[Install]" >> $_systemd_config_file
    echo "WantedBy=multi-user.target" >> $_systemd_config_file

    chroot $chroot_path systemctl enable "${_AM_INSTALLGA_}.service"

    # This part validates presence of Python & whether installga service has properly enabled.
    trace "Checking for linux installation prereqs within source vm."

    gacheck=$(chroot $chroot_path python3 --version)
    trace "Python 3 version. Absent if empty or fails: $gacheck"

    gacheck=$(chroot $chroot_path python --version)
    trace "Python 2 version. Absent if empty or fails: $gacheck"

    gacheck=$(cat $_systemd_config_file)
    trace "systemd service file: $gacheck"
    
    gacheck=$(cat $chroot_path/$asr_installga_exfile_path)
    trace "asr.installga: $gacheck"
}

enable_custom_script_service()
{
    # Startup script to install azure guest agent.
    local asr_customscript_exfile_path="usr/local/${_AM_CUSTOM_SCRIPT_}/asr.user_script"

    # Create a directory if it doesn't exist.
    if [[ ! -d "$chroot_path/usr/local/${_AM_CUSTOM_SCRIPT_}" ]]; then
        trace "Creating a new directory /usr/local/${_AM_CUSTOM_SCRIPT_}"
        mkdir "$chroot_path/usr/local/${_AM_CUSTOM_SCRIPT_}"
    fi
    
    if [[ -f $chroot_path/$asr_customscript_exfile_path ]]; then
        trace "/usr/local/${_AM_CUSTOM_SCRIPT_}/user_script.sh exists. Deleting the file."
        rm $chroot_path/$asr_customscript_exfile_path
    fi
 
    # Write execution commands for user_script.sh executable.
    trace "Creating user_script.sh for execution during boot."

    echo "#!/bin/bash" >> $chroot_path/$asr_customscript_exfile_path
    echo "#This file is generated for execution during boot!!!!" >> $chroot_path/$asr_customscript_exfile_path
    echo "cd /usr/local/AzureRecovery/user_files/" >> $chroot_path/$asr_customscript_exfile_path
    echo "bash /var/user_files/CommandsToExecute.sh"  >> $chroot_path/$asr_customscript_exfile_path
    echo "exit 0" >> $chroot_path/$asr_customscript_exfile_path

    # Add executable permissions.
    chmod +x $chroot_path/$asr_customscript_exfile_path

    # Check for systemd path. The path may vary among linux distros.
    local _systemd_config_file="$chroot_path/lib/systemd/system/${_AM_CUSTOM_SCRIPT_}.service"
    if [[ ! -d $chroot_path/lib/systemd/system ]]; then
        if [[ -d $chroot_path/usr/lib/systemd/system ]]; then
            _systemd_config_file="$chroot_path/usr/lib/systemd/system/${_AM_CUSTOM_SCRIPT_}.service"
        elif [[ -d $chroot_path/etc/systemd/system ]]; then
            _systemd_config_file="$chroot_path/etc/systemd/system/${_AM_CUSTOM_SCRIPT_}.service"
        fi
    fi

    # Delete the file if it already exists
    if [[ -f $_systemd_config_file ]]; then
        trace "$_systemd_config_file exists. Deleting the file."
        rm $_systemd_config_file
    fi

    trace "Creating systemd config file. $_systemd_config_file"

    echo "[Unit]" >> $_systemd_config_file
    echo "Description=Install Azure Linux Guest agent startup script by ASR" >> $_systemd_config_file
    echo "ConditionPathExists=/$asr_customscript_exfile_path" >> $_systemd_config_file
    echo "" >> $_systemd_config_file
    echo "[Service]" >> $_systemd_config_file
    echo "Type=forking" >> $_systemd_config_file
    echo "ExecStart=/$asr_customscript_exfile_path start" >> $_systemd_config_file
    echo "TimeoutSec=0" >> $_systemd_config_file
    echo "StandardOutput=tty" >> $_systemd_config_file
    echo "RemainAfterExit=yes" >> $_systemd_config_file
    echo "SysVStartPriority=99" >> $_systemd_config_file
    echo "" >> $_systemd_config_file
    echo "[Install]" >> $_systemd_config_file
    echo "WantedBy=multi-user.target" >> $_systemd_config_file

    chroot $chroot_path systemctl enable "${_AM_CUSTOM_SCRIPT_}.service"

    # This part validates presence of Python & whether installga service has properly enabled.
    trace "Checking for linux installation prereqs within source vm."

    gacheck=$(chroot $chroot_path python3 --version)
    trace "Python 3 version. Absent if empty or fails: $gacheck"

    gacheck=$(chroot $chroot_path python --version)
    trace "Python 2 version. Absent if empty or fails: $gacheck"

    gacheck=$(cat $_systemd_config_file)
    trace "systemd service file: $gacheck"
    
    gacheck=$(cat $chroot_path/$asr_customscript_exfile_path)
    trace "user_script.sh: $gacheck"
}

fix_network_config()
{
    trace "Making network changes ..."
    case $src_distro in
    RHEL6*|CENTOS6*|OL6*)
        remove_network_manager_rpm
        update_network_file
        enable_network_service
        configure_dhcp_rhel
        add_startup_script_for_dhcp
    ;;
    SLES11*|SLES12*)
        remove_network_manager_rpm
        update_network_dhcp_file
        configure_dhcp_sles
        add_startup_script_for_dhcp
    ;;
    UBUNTU14*|DEBIAN*|UBUNTU16*)
        remove_persistent_net_rules
        configure_dhcp_ubuntu
        add_startup_script_for_dhcp
    ;;
    UBUNTU18*)
        remove_persistent_net_rules
        create_dhcp_netplan_config_and_apply
    ;;
    RHEL7*|RHEL8*)
        update_network_file
        enable_network_service
        configure_dhcp_rhel
        add_startup_script_for_dhcp
    ;;
    CENTOS7*|OL7*|CENTOS8*)
        reset_persistent_net_gen_rules
        update_network_file
        configure_dhcp_rhel
        add_startup_script_for_dhcp
    ;;
    *)
        throw_error $_E_AZURE_SMS_OS_UNSUPPORTED $src_distro
    ;;
    esac
    trace "Successfully completed network changes!"
}

update_lvm_conf_to_allow_all_device_types()
{
    local _lvm_conf_file_="${chroot_path}/etc/lvm/lvm.conf"
    
    if [[ -f $_lvm_conf_file_ ]]; then
        trace "$_lvm_conf_file_ not found."
        return 0
    fi
    
    # Modify lvm.conf file to include all devices.
    local _line_=$(cat "$_lvm_conf_file_" | grep -P "^(\s*)filter(\s*)=(\s*).*")
    if [[ ! -z "$_line_" ]]; then
        backup_file $_lvm_conf_file_
        _line_number_=$(cat "$_lvm_conf_file_" | grep -P -n "^(\s*)filter(\s*)=(\s*).*" | awk -F":" '{print $1}')
        trace "Modifying filter in $_lvm_conf_file_ (line: $_line_number_)"
        sed -i "$_line_number_ c\filter=\"a\/.*\/\"" $_lvm_conf_file_
        return $?
    fi

    return 0
}

update_root_device_uuid_in_boot_cmd()
{
    local _boot_cmd_starts_with_="linux"
    local _grub_file_="${chroot_path}/boot/grub2/grub.cfg"
    
    case $src_distro in
        CENTOS6*|OL6*|RHEL6*|SLES11*)
            _grub_file_="${chroot_path}/boot/grub/menu.lst"
            if [ "$firmware_type" = "UEFI" ]; then
                _grub_file_="$_grub2_efi_path/menu.lst"
            fi
            _boot_cmd_starts_with_="kernel"
        ;;
        UBUNTU*|DEBIAN*)
            _grub_file_="${chroot_path}/boot/grub/grub.cfg"
            if [ "$firmware_type" = "UEFI" ]; then
                _grub_file_="$_grub2_efi_path/grub.cfg"
            fi
        ;;
    esac

    if [ "$firmware_type" = "UEFI" ]; then
        if [ -f "$_grub2_efi_path/grub.cfg" ]; then
            _grub_file_="$_grub2_efi_path/grub.cfg"
        elif [ -f "$_grub2_efi_path/menu.lst" ]; then
            _grub_file_="$_grub2_efi_path/menu.lst"
        elif [ -f "$_grub2_efi_path/grub.conf" ]; then
            _grub_file_="$_grub2_efi_path/grub.conf"
        fi
    fi
    
    local src_root_uuid=$(findmnt -nf -o UUID $chroot_path)
    if [[ $? -ne 0 ]]; then
        trace "could not find device UUID for the $chroot_path"
        return 0
    elif [[ -z $src_root_uuid ]]; then
        trace "root UUID not available, skipping root device update in grub file."
        return 0
    fi
    
    exec 4<$_grub_file_
    while read -u 4 -r _line_
    do
        # Ignore commented lines
        if [[ $_line_ =~ ^# ]]; then
            continue
        fi
        
        local _dev_name_=$(echo $_line_ |\
                         grep "${_boot_cmd_starts_with_}.*root=\/dev\/" |\
                         awk -F"root=" '{print $2}' | awk '{print $1}')

        [[ -z $_dev_name_ ]] && continue
        
        if [[ $_dev_name_ =~ /dev/[x]*[svh]d.* ]]; then
            trace "Replacing $_dev_name_ with $src_root_uuid"
            local safe_device=$(printf "%s\n" "$_dev_name_" |\
                         sed 's/[][\.*^$(){}?+|/]/\\&/g')
            sed -i --follow-symlinks "s/${safe_device}/UUID=$src_root_uuid/" $_grub_file_
        else
            trace "$_dev_name_ is not a standard partition name, no need to replace with UUID."
        fi
        
        # TODO: Remove "resume=" option if its referring to standard device name.
    done
    4<&-    
}

main()
{
    local error_in_generate_initrd_image=0
    validate_script_input "$@"
    
    verify_src_os_version

    get_firmware_type

    mount_runtime_partitions

    verify_requited_tools

    verify_generate_initrd_images
    # Error is saved so it can be returned to caller.
    error_in_generate_initrd_image=$?
    
    set_serial_console_grub_options    

    verify_uefi_bootloader_files

    update_root_device_uuid_in_boot_cmd
    
    fix_network_config
    
    update_lvm_conf_to_allow_all_device_types

    # Last step to avoid failures.
    user_disable_ga_config="EnableGA:false"
    if [[ $custom_config_settings =~ .*$user_disable_ga_config.* ]]; then
        trace " User Opted to turn off Linux guest agent installation."
    else
        # Check if EnableLinuxGAInstalaltion is set to true.
        enable_linux_guest_agent_config="EnableLinuxGAInstallation:true"
        if [[ $hydration_config_settings =~ .*$enable_linux_guest_agent_config.* ]]; then
            install_linux_guest_agent
            if [[ $? -ne 0 ]]; then
                trace "Could not push linux guest agent binaries on target vm."
            fi
        else
            trace "Linux guest agent installation setting is turned off."
        fi
    fi
    if [[ CUSTOM_SCRIPT -ne 0 ]]; then
        install_custom_script_agent
        if [[ $? -ne 0 ]]; then
            trace "Error with running custom_script by user"
        fi
    fi
    # Return error if any in generate_initrd_image.
    # TODO: For completeness, we should return a bitmap with each bit representing 
    # failure in each of 10 steps. That way we can parse the bitmap and report how many
    # steps failed.
    return $error_in_generate_initrd_image
}

main "$@"