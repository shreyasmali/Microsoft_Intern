#!/bin/bash

##+----------------------------------------------------------------------------------+
##            Copyright(c) Microsoft Corp. 2021
##+----------------------------------------------------------------------------------+
## File         :   InstallLinuxGuestAgent.sh
##
## Description  :   Script invoked by rc.local on Migrated/Failed-over VM.
##                  Executes steps to install guest agent on the VM.
##
## History      :   29-01-2021 (Shantanu Mishra) - Created
##+----------------------------------------------------------------------------------+

# Check for the version of python
function CheckValidPythonVersion
{
    python3 --version
    if [[ $? -ne 0 ]] ; then
        echo "Python3 is not installed on the VM."
    else
        return 3;
    fi
    
    python --version
    if [[ $? -ne 0 ]] ; then
        echo "Python is not installed on the VM."
        return 0;
    else
        vermajor=$(python -c"import platform; major, minor, patch = platform.python_version_tuple(); print(major)")
        verminor=$(python -c"import platform; major, minor, patch = platform.python_version_tuple(); print(minor)")
        if [ $vermajor -eq 2 ] && [ $verminor -ge 6 ]; then
            return 2;
        else
            echo "Python version 2.6+ is not installed on the VM."
            return 0;
        fi
    fi    

    return 0;
}

checkAzureGAInstalled=$(systemctl status walinuxagent)
if [[ $checkAzureGAInstalled == *"active"* ]] && [[ $checkAzureGAInstalled == *"running"* ]]; then
    echo "Ubuntu: Linux Guest Agent is already installed on the VM and is running."
    exit 0
else
    checkAzureGAInstalled=$(systemctl status waagent)
        if [[ $checkAzureGAInstalled == *"active"* ]] && [[ $checkAzureGAInstalled == *"running"* ]]; then
        echo "Linux Guest Agent is already installed on the VM and is running."
        exit 0
    fi
fi

if [[ ! -d "/var/WALinuxAgentASR" ]]; then
    echo "Guest agent installation folder not found.\n"
    echo "This should be second boot of VM since migration to Azure, hence skipping guest agent installation."
    exit 0
fi

CheckValidPythonVersion
pythonversion=$?
echo "Python version is $pythonversion"

if [ $pythonversion -eq 0 ]; then
    echo "Failed to install Linux Guest Agent on the VM.\n"
    echo "Install python version 2.6+ to install Guest Agent.\n"
    exit 0
fi

if [ $pythonversion -eq 3 ]; then
    python3 /var/PythonSetupPrereqs.py
    cd /var/WALinuxAgentASR/WALinuxAgent-master
    python3 setup.py install --register-service --force

    # Replace python executable commands with python3
    cat bin/waagent | sed 's_#!/usr/bin/env python_#!/usr/bin/env python3_' > /usr/sbin/waagent
    if [ -f '/usr/lib/systemd/system/waagent.service' ]; then
        cat /usr/lib/systemd/system/waagent.service | sed -i 's_ExecStart=/usr/bin/python_ExecStart=/usr/bin/python3_' /usr/lib/systemd/system/waagent.service
    fi
    if [ -f '/lib/systemd/system/waagent.service' ]; then 
        cat /lib/systemd/system/waagent.service | sed -i 's_ExecStart=/usr/bin/python_ExecStart=/usr/bin/python3_' /lib/systemd/system/waagent.service
    fi
	if [ -f '/usr/lib/systemd/system/walinuxagent.service' ]; then
        cat /usr/lib/systemd/system/walinuxagent.service | sed -i 's_ExecStart=/usr/bin/python_ExecStart=/usr/bin/python3_' /usr/lib/systemd/system/walinuxagent.service
    fi
    if [ -f '/lib/systemd/system/walinuxagent.service' ]; then 
        cat /lib/systemd/system/walinuxagent.service | sed -i 's_ExecStart=/usr/bin/python_ExecStart=/usr/bin/python3_' /lib/systemd/system/walinuxagent.service
    fi

    # Make waagent as executable file, reload system-daemon and restart waagent
    chmod +x /usr/sbin/waagent
    systemctl daemon-reload
    systemctl stop waagent
    systemctl start waagent
    systemctl status waagent
fi

if [ $pythonversion -eq 2 ]; then
    python /var/PythonSetupPrereqs.py
    cd /var/WALinuxAgentASR/WALinuxAgent-master
    python setup.py install --register-service --force

    # Make waagent as executable file, reload system-daemon and restart waagent
    chmod +x /usr/sbin/waagent
    systemctl stop waagent
    systemctl start waagent
    systemctl status waagent
fi

# Remove the folder and file to make subsequent boots faster.
rm -rf /var/WALinuxAgentASR
rm -f /var/PythonSetupPrereqs.py
exit 0